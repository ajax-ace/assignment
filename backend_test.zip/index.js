const express = require('express');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser')

const conn = require('./database/mysql');

const app = express()
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());

app.get("/login", function (req, res) {
    res.sendFile(__dirname + "/login.html");
})

app.get("/register", function (req, res) {
    res.sendFile(__dirname + "/register.html");
})
app.get('/', (req, res) => {
    res.sendFile(__dirname + "/index.html");
})

app.get("/welcome", (req, res) => {

    let user = req.cookies.username;

    if (user) {
        res.sendFile(__dirname + "/welcome.html");
    }
    else {
        res.redirect('/login');
    }

})

app.post('/register', function (req, res) {
    let username = req.body.username;
    let password = req.body.password;
    let email = req.body.email;

    const myquery = `insert into data values("${username}","${email}","${password}")`;

    conn.query(myquery, (err, result) => {
        if (err) {
            console.log(err);
            res.end();
        }
        else {
            res.redirect('/login');
            console.log(result);
        }
    })
})

app.post("/login", (req, res) => {
    let username = req.body.username;
    let password = req.body.password;

    let myquery = `select * from data where username="${username}" and password= "${password}"`;

    conn.query(myquery, (err, result) => {
        if (err) {
            console.log(err);
            res.end();
        }
        else {
            if (result.length == 1) {
                res.cookie("username", username,
                    {
                        maxAge: 60 * 60 * 1000,
                        sameSite: 'lax',
                        httpOnly: true
                    })
                res.redirect("/welcome");
            }
            else {
                res.send(`<p>Invalid login credentials</p>
                <form action="/register" method="GET">
            <button type="submit">Register</button>
        </form>
        <form action="/login" method="GET">
            <button type="submit">Login</button>
        </form>`)
            }
        }
    })
})

app.post("/clear", (req, res) => {
    res.clearCookie('username');
    res.redirect("/");
})

// app.get('/data', function(req,res){
//     const user = {
//         name : "shyam",
//         course : "MCA"
//     }
//     res.send(user);
// })

// app.post('/data', function(req,res){
//     console.log(req.body);
// })

app.listen(4001, function (err) {
    if (err)
        console.log(err);

    else {
        console.log("listening on 4001");
    }
});


